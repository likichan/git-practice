class BooksController < ApplicationController
  before_action :set_book, only: [:show, :edit, :update, :destroy]
  before_action :correct_user, only: [:edit, :update, :destroy]

  def index
    @books = Book.all
    @book = Book.new
  end

  def show
    @user = @book.user
  end

  def new
    @book = Book.new
  end

  def create
    @book = current_user.books.new(book_params)
    if @book.save
      redirect_to book_path(@book), notice: 'Book was successfully created.'
    else
      @books = Book.all
      flash.now[:alert] = @book.errors.full_messages
      render :index, status: :unprocessable_entity # ここを修正
    end
  end
  def edit
  end

  def update
    if @book.update(book_params)
      redirect_to @book, notice: 'Book was successfully updated.'
    else
      flash.now[:alert] = @book.errors.full_messages
      render :edit, status: :unprocessable_entity
    end
  end


  def destroy
    @book.destroy
    redirect_to books_url, notice: 'Book was successfully destroyed.'
  end

  private

  def set_book
    @book = Book.find(params[:id])
  end

  def book_params
    params.require(:book).permit(:title, :body)
  end

  def correct_user
    @book = current_user.books.find_by(id: params[:id])
    redirect_to books_path, notice: 'Not authorized to edit this book' if @book.nil?
  end
end