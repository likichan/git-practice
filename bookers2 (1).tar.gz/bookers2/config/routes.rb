Rails.application.routes.draw do
  devise_for :users
  root to: 'homes#top'
  get 'home/about', to: 'homes#about', as: 'about'

  resources :users, only: [:index, :show, :edit, :update] do
    resources :books, only: [:create]
  end

  resources :books, only: [:index, :show, :edit, :update, :destroy, :new, :create]
end
