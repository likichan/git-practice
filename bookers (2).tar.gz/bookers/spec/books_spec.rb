# frozen_string_literal: true

require 'rails_helper'

RSpec.describe "Books", type: :system do
  describe "トップ画面(root_path)のテスト" do
    before do
      visit root_path
    end

    it "トップ画面(root_path)に新規投稿ページへのリンクが表示されているか" do
      expect(page).to have_link 'start', href: new_book_path
    end

    it "root_pathが'/'であるか" do
      expect(current_path).to eq('/')
    end
  end

  describe "新規投稿ページ" do
    before do
      visit new_book_path
    end

    it "一覧の表示とリンクの確認" do
      expect(page).to have_selector 'table'
    end

    context "titleを空白で投稿した場合に画面にエラーメッセージが表示されるか" do
      before do
        fill_in 'book[title]', with: ''
        fill_in 'book[body]', with: 'Sample Body'
      end

      it "エラーメッセージは正しく表示されるか" do
        find("input[name='commit']").click
        expect(page).to have_content "can't be blank"
      end
    end

    context "bodyを空白で投稿した場合に画面にエラーメッセージが表示されるか" do
      before do
        fill_in 'book[title]', with: 'Sample Title'
        fill_in 'book[body]', with: ''
      end

      it "エラーメッセージは正しく表示されるか" do
        find("input[name='commit']").click
        expect(page).to have_content "can't be blank"
      end
    end
  end
end
